import React, { useState, useEffect, useCallback, useMemo } from "react";
import ProductList from "./components/ProductList";
import SearchBar from "./components/SearchBar";

const App = () => {
  const [products, setProducts] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");

  // Fetch products from Fake Store API
  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await fetch("https://fakestoreapi.com/products");
        const data = await response.json();
        setProducts(data); // Set the product data
      } catch (error) {
        console.error("Error fetching products:", error);
      }
    };
    fetchProducts();
  }, []);

  // Optimized filtering with useMemo
  const filteredProducts = useMemo(() => {
    return products.filter((product) =>
      product.title.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [products, searchTerm]);

  // Optimized clear button with useCallback
  const clearSearch = useCallback(() => {
    setSearchTerm("");
  }, []);

  return (
    <div style={{ padding: "20px" }}>
      <h1>Filterable Product List</h1>
      <SearchBar searchTerm={searchTerm} setSearchTerm={setSearchTerm} clearSearch={clearSearch} />
      <h3>Count of Products: {filteredProducts.length}</h3>
      <ProductList products={filteredProducts} />
    </div>
  );
};

export default App;
